USE esame_sql;

/* Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare 
l’univocità dei valori di ciascuna PK (una query per tabella implementata). */

SELECT COUNT(*) FROM dimcategory GROUP BY CategoryKey HAVING COUNT(*) > 1;
SELECT COUNT(*) FROM dimcity GROUP BY CityKey HAVING COUNT(*) > 1;
SELECT COUNT(*) FROM dimgeography GROUP BY GeographyKey HAVING COUNT(*) > 1;
SELECT COUNT(*) FROM dimproduct GROUP BY ProductKey HAVING COUNT(*) > 1;
SELECT COUNT(*) FROM dimregion GROUP BY RegionKey HAVING COUNT(*) > 1;
SELECT COUNT(*) FROM dimreseller GROUP BY ResellerKey HAVING COUNT(*) > 1;
SELECT COUNT(*) FROM dimstate GROUP BY StateKey HAVING COUNT(*) > 1;
SELECT COUNT(*) FROM factsales GROUP BY OrderID HAVING COUNT(*) > 1;



/* Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del 
prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo 
booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o 
meno (>180 -> True, <= 180 -> False). */

SELECT
fs.OrderID Codice_Ordine
, fs.OrderDate Data
, dp.ProductName Prodotto
, dc.CategoryName Categoria
, ds.StateName Stato
, drg.RegionName Regione
, CASE
	WHEN DATEDIFF(CURDATE(), fs.OrderDate) > 180 THEN 'True'
    ELSE 'False'
    END Precedente_A_Semestre_Attuale
FROM factsales fs
JOIN dimproduct dp ON fs.ProductKey = dp.ProductKey
JOIN dimcategory dc ON dp.CategoryKey = dc.CategoryKey
JOIN dimreseller drs ON fs.ResellerKey = drs.ResellerKey
JOIN dimgeography dg ON drs.GeographyKey = dg.GeographyKey
JOIN dimregion drg ON drg.RegionKey = dg.RegionKey
JOIN dimstate ds ON dg.StateKey = ds.StateKey
ORDER BY fs.OrderDate;



/* Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle 
vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e 
non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale 
venduto. */

SELECT 
ProductKey Chiave_Prodotto
, SUM(SalesAmount) Totale_Venduto
FROM factsales
WHERE DATEDIFF((SELECT OrderDate FROM factsales ORDER BY OrderDate DESC LIMIT 1), OrderDate) <= 365
GROUP BY ProductKey
HAVING SUM(SalesAmount) >
	(SELECT AVG(Totale_Prodotto)
    FROM 
		(SELECT SUM(SalesAmount) Totale_Prodotto
		FROM factsales
        WHERE DATEDIFF((SELECT OrderDate FROM factsales ORDER BY OrderDate DESC LIMIT 1), OrderDate) <= 365
        GROUP BY ProductKey) A);
      
      
        
/* Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */

SELECT dp.ProductName Prodotto, YEAR(OrderDate) Anno, SUM(SalesAmount) Fatturato
FROM factsales fs
JOIN dimproduct dp
ON fs.ProductKey = dp.ProductKey
GROUP BY fs.ProductKey, dp.ProductName, YEAR(OrderDate)
ORDER BY Prodotto, Anno;



/* Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. */

SELECT 
ds.StateName Stato
, YEAR(fs.OrderDate) Anno
, SUM(SalesAmount) Fatturato
FROM factsales fs
JOIN dimreseller dr
ON fs.ResellerKey = dr.ResellerKey
JOIN dimgeography dg
ON dr.GeographyKey = dg.GeographyKey
JOIN dimregion drg
ON dg.RegionKey = drg.RegionKey
JOIN dimstate ds
ON ds.RegionKey = drg.RegionKey
GROUP BY ds.StateKey, ds.StateName, YEAR(fs.OrderDate)
ORDER BY Anno, Fatturato DESC; 



/* Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? */

SELECT 
Categoria Maggiore_Categoria
, Fatturato
FROM 
	(SELECT 
	dc.CategoryName Categoria
	, SUM(SalesAmount) Fatturato
	FROM factsales fs
	JOIN dimproduct dp
	ON fs.ProductKey = dp.ProductKey
	JOIN dimcategory dc
	ON dp.CategoryKey = dc.CategoryKey
	GROUP BY dc.CategoryKey, dc.CategoryName
	ORDER BY Fatturato DESC
	LIMIT 1) A;
    
    
    
/* Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi 
differenti. */

SELECT *
FROM dimproduct
WHERE ProductKey NOT IN (SELECT ProductKey FROM factsales);

SELECT dp.*
FROM dimproduct dp
LEFT JOIN factsales fs 
ON dp.ProductKey = fs.ProductKey
WHERE fs.ProductKey IS NULL;



/* Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni 
utili (codice prodotto, nome prodotto, nome categoria). */

CREATE VIEW gp_view_product AS (
SELECT 
dp.ProductKey Chiave_Prodotto
, dp.ProductName Prodotto
, dc.CategoryName Categoria
FROM dimproduct dp
JOIN dimcategory dc
ON dp.CategoryKey = dc.CategoryKey);



/* Creare una vista per le informazioni geografiche. */

CREATE VIEW gp_view_geography AS (
SELECT dg.GeographyKey GeographyKey
, dc.CityName Città
, ds.StateName Stato
, dr.RegionName Regione
FROM dimgeography dg
JOIN dimregion dr
ON dg.RegionKey = dr.RegionKey
JOIN dimstate ds
ON dg.StateKey = ds.StateKey
JOIN dimcity dc
ON dg.CityKey = dc.CityKey);