/* Creazione del database */
DROP DATABASE IF EXISTS `esame_sql`;
CREATE DATABASE esame_sql;
USE esame_sql;



/* Creazione delle tabelle rappresentanti entità e attributi */
CREATE TABLE DimProduct (
ProductKey INT NOT NULL
, ProductName VARCHAR(100) NOT NULL
, Description VARCHAR(150)
, ListPrice DECIMAL(10, 2) NOT NULL
, CategoryKey INT);

CREATE TABLE DimCategory (
CategoryKey INT NOT NULL
, CategoryName VARCHAR(100) NOT NULL
, Description VARCHAR(150));

CREATE TABLE DimReseller (
ResellerKey INT NOT NULL
, ResellerName VARCHAR(100) NOT NULL
, GeographyKey INT);

CREATE TABLE DimGeography (
GeographyKey INT NOT NULL
, RegionKey INT
, StateKey INT
, CityKey INT);

CREATE TABLE DimRegion (
RegionKey INT NOT NULL
, RegionName VARCHAR(100) NOT NULL);

CREATE TABLE DimState (
StateKey INT NOT NULL
, StateName VARCHAR(100) NOT NULL
, RegionKey INT);

CREATE TABLE DimCity (
CityKey INT NOT NULL
, CityName VARCHAR(100) NOT NULL
, StateKey INT);

CREATE TABLE FactSales (
OrderID INT NOT NULL
, ProductKey INT
, ResellerKey INT
, OrderDate DATE NOT NULL
, SalesAmount DECIMAL(10, 2) NOT NULL);



/* Creazione delle relazioni tra le tabelle, attraverso l'utilizzo di PK, FK e vincoli */
ALTER TABLE esame_sql.dimcategory
MODIFY CategoryKey INT AUTO_INCREMENT
, ADD CONSTRAINT PK_product PRIMARY KEY(CategoryKey);

ALTER TABLE esame_sql.dimproduct
MODIFY ProductKey INT AUTO_INCREMENT
, ADD CONSTRAINT PK_product PRIMARY KEY(ProductKey)
, ADD CONSTRAINT FK_category FOREIGN KEY(CategoryKey)
REFERENCES dimcategory (CategoryKey);

ALTER TABLE esame_sql.dimregion
MODIFY RegionKey INT AUTO_INCREMENT
, ADD CONSTRAINT PK_region PRIMARY KEY(RegionKey);

ALTER TABLE esame_sql.dimstate
MODIFY StateKey INT AUTO_INCREMENT
, ADD CONSTRAINT PK_state PRIMARY KEY(StateKey)
, ADD CONSTRAINT FK_region FOREIGN KEY(RegionKey)
REFERENCES dimregion (RegionKey);

ALTER TABLE esame_sql.dimcity
MODIFY CityKey INT AUTO_INCREMENT
, ADD CONSTRAINT PK_city PRIMARY KEY(CityKey)
, ADD CONSTRAINT FK_state FOREIGN KEY(StateKey)
REFERENCES dimstate (StateKey);

ALTER TABLE esame_sql.dimgeography
MODIFY GeographyKey INT AUTO_INCREMENT
, ADD CONSTRAINT PK_geography PRIMARY KEY(GeographyKey)
, ADD CONSTRAINT FK_georegion FOREIGN KEY(RegionKey)
REFERENCES dimregion (RegionKey)
, ADD CONSTRAINT FK_geostate FOREIGN KEY(StateKey)
REFERENCES dimstate (StateKey)
, ADD CONSTRAINT FK_geocity FOREIGN KEY(CityKey)
REFERENCES dimcity (CityKey);

ALTER TABLE esame_sql.dimreseller
MODIFY ResellerKey INT AUTO_INCREMENT
, ADD CONSTRAINT PK_reseller PRIMARY KEY(ResellerKey)
, ADD CONSTRAINT FK_geography FOREIGN KEY(GeographyKey)
REFERENCES dimgeography (GeographyKey);

ALTER TABLE esame_sql.factsales
MODIFY OrderID INT AUTO_INCREMENT
, ADD CONSTRAINT PK_sales PRIMARY KEY(OrderID)
, ADD CONSTRAINT FK_product FOREIGN KEY(ProductKey)
REFERENCES dimproduct (ProductKey)
, ADD CONSTRAINT FK_resellersales FOREIGN KEY(ResellerKey)
REFERENCES dimreseller (ResellerKey);



/* Inserimento dei dati e popolazione tabelle */
INSERT INTO DimCategory (CategoryName, Description)
VALUES
    ('Toys', 'General toys for children of all ages'),
    ('Educational', 'Educational toys for learning purposes'),
    ('Outdoor', 'Toys and equipment for outdoor activities'),
    ('Electronics', 'Electronic toys and gadgets'),
    ('Board Games', 'Games for family and friends'),
    ('Puzzles', 'Various puzzles for mental development'),
    ('Plush', 'Plush toys and stuffed animals'),
    ('Vehicles', 'Toy cars, trucks, and other vehicles');
    
INSERT INTO DimProduct (ProductName, Description, CategoryKey, ListPrice)
VALUES
    ('Action Figure', 'Superhero action figure with articulated limbs', 1, 15.99),
    ('Building Blocks', 'Colorful building blocks for young children', 1, 12.50),
    ('Doll', 'Classic doll with accessories', 1, 20.00),
    ('Alphabet Puzzle', 'Wooden puzzle to learn the alphabet', 2, 10.99),
    ('Science Kit', 'Basic science kit for experiments', 2, 25.00),
    ('Math Flashcards', 'Flashcards for basic math skills', 2, 5.99),
    ('Jump Rope', 'Durable jump rope for outdoor play', 3, 7.50),
    ('Frisbee', 'Plastic frisbee for outdoor fun', 3, 6.00),
    ('Kite', 'Colorful kite for windy days', 3, 12.00),
    ('Remote Control Car', 'RC car with rechargeable battery', 4, 29.99),
    ('Tablet for Kids', 'Kid-friendly tablet with educational games', 4, 60.00),
    ('Robot Toy', 'Programmable robot for beginners', 4, 45.50),
    ('Classic Chess Set', 'Wooden chess set for all ages', 5, 18.99),
    ('Family Board Game', 'Fun board game for family gatherings', 5, 22.50),
    ('Card Game', 'Popular card game with 52 cards', 5, 8.00),
    ('1000-piece Puzzle', 'Large puzzle with a scenic image', 6, 14.00),
    ('3D Puzzle', '3D puzzle to build a famous landmark', 6, 20.00),
    ('Animal Puzzle', 'Puzzle with animal images for children', 6, 9.50),
    ('Teddy Bear', 'Soft teddy bear in brown color', 7, 12.00),
    ('Unicorn Plush', 'Colorful unicorn plush toy', 7, 15.00),
    ('Dinosaur Plush', 'Green dinosaur plush for kids', 7, 13.00),
    ('Toy Truck', 'Miniature truck with moving parts', 8, 10.00),
    ('Race Car', 'Fast toy race car with cool design', 8, 9.50),
    ('Helicopter', 'Toy helicopter with spinning rotor', 8, 11.50);

INSERT INTO DimRegion (RegionName)
VALUES
    ('North Europe'),
    ('South Europe'),
    ('East Europe'),
    ('West Europe'),
    ('North America'),
    ('Central America'),
    ('South America'),
    ('East Asia'),
    ('South Asia'),
    ('Southeast Asia'),
    ('Central Asia'),
    ('West Asia'),
    ('North Africa'),
    ('West Africa'),
    ('East Africa'),
    ('Central Africa'),
    ('Southern Africa'),
    ('Australia and New Zealand'),
    ('Pacific Islands');
    
-- Inserimento dei dati in DimState
INSERT INTO DimState (StateName, RegionKey)
VALUES
    ('Norway', 1),
    ('Sweden', 1),
    ('Italy', 2),
    ('Greece', 2),
    ('Poland', 3),
    ('Romania', 3),
    ('France', 4),
    ('Germany', 4),
    ('United States', 5),
    ('Canada', 5),
    ('Mexico', 6),
    ('Guatemala', 6),
    ('Brazil', 7),
    ('Argentina', 7),
    ('China', 8),
    ('Japan', 8),
    ('India', 9),
    ('Pakistan', 9),
    ('Thailand', 10),
    ('Vietnam', 10),
    ('Kazakhstan', 11),
    ('Uzbekistan', 11),
    ('Turkey', 12),
    ('Saudi Arabia', 12),
    ('Egypt', 13),
    ('Libya', 13),
    ('Nigeria', 14),
    ('Ghana', 14),
    ('Kenya', 15),
    ('Ethiopia', 15),
    ('Democratic Republic of the Congo', 16),
    ('Central African Republic', 16),
    ('South Africa', 17),
    ('Namibia', 17),
    ('Australia', 18),
    ('New Zealand', 18),
    ('Fiji', 19),
    ('Papua New Guinea', 19);

INSERT INTO DimCity (CityName, StateKey)
VALUES
    ('Oslo', 1),
    ('Bergen', 1),
    ('Stavanger', 1),
    ('Stockholm', 2),
    ('Gothenburg', 2),
    ('Malmo', 2),
    ('Rome', 3),
    ('Milan', 3),
    ('Naples', 3),
    ('Athens', 4),
    ('Thessaloniki', 4),
    ('Patras', 4),
    ('Warsaw', 5),
    ('Krakow', 5),
    ('Gdansk', 5),
    ('Bucharest', 6),
    ('Cluj-Napoca', 6),
    ('Timisoara', 6),
    ('Paris', 7),
    ('Lyon', 7),
    ('Marseille', 7),
    ('Berlin', 8),
    ('Munich', 8),
    ('Hamburg', 8),
    ('New York', 9),
    ('Los Angeles', 9),
    ('Chicago', 9),
    ('Toronto', 10),
    ('Vancouver', 10),
    ('Montreal', 10),
    ('Mexico City', 11),
    ('Guadalajara', 11),
    ('Monterrey', 11),
    ('Guatemala City', 12),
    ('Mixco', 12),
    ('Villa Nueva', 12),
    ('Sao Paulo', 13),
    ('Rio de Janeiro', 13),
    ('Brasilia', 13),
    ('Buenos Aires', 14),
    ('Cordoba', 14),
    ('Rosario', 14),
    ('Beijing', 15),
    ('Shanghai', 15),
    ('Guangzhou', 15),
    ('Tokyo', 16),
    ('Osaka', 16),
    ('Nagoya', 16),
    ('Mumbai', 17),
    ('Delhi', 17),
    ('Bangalore', 17),
    ('Karachi', 18),
    ('Lahore', 18),
    ('Islamabad', 18),
    ('Bangkok', 19),
    ('Chiang Mai', 19),
    ('Pattaya', 19),
    ('Hanoi', 20),
    ('Ho Chi Minh City', 20),
    ('Da Nang', 20),
    ('Almaty', 21),
    ('Nur-Sultan', 21),
    ('Shymkent', 21),
    ('Tashkent', 22),
    ('Samarkand', 22),
    ('Bukhara', 22),
    ('Istanbul', 23),
    ('Ankara', 23),
    ('Izmir', 23),
    ('Riyadh', 24),
    ('Jeddah', 24),
    ('Dammam', 24),
    ('Cairo', 25),
    ('Alexandria', 25),
    ('Giza', 25),
    ('Tripoli', 26),
    ('Benghazi', 26),
    ('Misrata', 26),
    ('Lagos', 27),
    ('Abuja', 27),
    ('Ibadan', 27),
    ('Accra', 28),
    ('Kumasi', 28),
    ('Tamale', 28),
    ('Nairobi', 29),
    ('Mombasa', 29),
    ('Kisumu', 29),
    ('Addis Ababa', 30),
    ('Dire Dawa', 30),
    ('Mekelle', 30),
    ('Kinshasa', 31),
    ('Lubumbashi', 31),
    ('Goma', 31),
    ('Bangui', 32),
    ('Bimbo', 32),
    ('Berberati', 32),
    ('Johannesburg', 33),
    ('Cape Town', 33),
    ('Durban', 33),
    ('Windhoek', 34),
    ('Swakopmund', 34),
    ('Walvis Bay', 34),
    ('Sydney', 35),
    ('Melbourne', 35),
    ('Brisbane', 35),
    ('Auckland', 36),
    ('Wellington', 36),
    ('Christchurch', 36),
    ('Suva', 37),
    ('Lautoka', 37),
    ('Nadi', 37),
    ('Port Moresby', 38),
    ('Lae', 38),
    ('Mount Hagen', 38);

INSERT INTO DimGeography (CityKey, StateKey, RegionKey)
VALUES
    (1, 1, 1),
    (2, 1, 1),
    (3, 1, 1),
    (4, 2, 1),
    (5, 2, 1),
    (6, 2, 1),
    (7, 3, 2),
    (8, 3, 2),
    (9, 3, 2),
    (10, 4, 2),
    (11, 4, 2),
    (12, 4, 2),
    (13, 5, 3),
    (14, 5, 3),
    (15, 5, 3),
    (16, 6, 3),
    (17, 6, 3),
    (18, 6, 3),
    (19, 7, 4),
    (20, 7, 4),
    (21, 7, 4),
    (22, 8, 4),
    (23, 8, 4),
    (24, 8, 4),
    (25, 9, 5),
    (26, 9, 5),
    (27, 9, 5),
    (28, 10, 5),
    (29, 10, 5),
    (30, 10, 5),
    (31, 11, 6),
    (32, 11, 6),
    (33, 11, 6),
    (34, 12, 6),
    (35, 12, 6),
    (36, 12, 6),
    (37, 13, 7),
    (38, 13, 7),
    (39, 13, 7),
    (40, 14, 7),
    (41, 14, 7),
    (42, 14, 7),
    (43, 15, 8),
    (44, 15, 8),
    (45, 15, 8),
    (46, 16, 8),
    (47, 16, 8),
    (48, 16, 8),
    (49, 17, 9),
    (50, 17, 9),
    (51, 17, 9),
    (52, 18, 9),
    (53, 18, 9),
    (54, 18, 9),
    (55, 19, 10),
    (56, 19, 10),
    (57, 19, 10),
    (58, 20, 10),
    (59, 20, 10),
    (60, 20, 10),
    (61, 21, 11),
    (62, 21, 11),
    (63, 21, 11),
    (64, 22, 12),
    (65, 22, 12),
    (66, 22, 12),
    (67, 23, 12),
    (68, 23, 12),
    (69, 23, 12),
    (70, 24, 12),
    (71, 24, 12),
    (72, 24, 12),
    (73, 25, 13),
    (74, 25, 13),
    (75, 25, 13),
    (76, 26, 13),
    (77, 26, 13),
    (78, 26, 13),
    (79, 27, 14),
    (80, 27, 14),
    (81, 27, 14),
    (82, 28, 14),
    (83, 28, 14),
    (84, 28, 14),
    (85, 29, 15),
    (86, 29, 15),
    (87, 29, 15),
    (88, 30, 15),
    (89, 30, 15),
    (90, 30, 15),
    (91, 31, 16),
    (92, 31, 16),
    (93, 31, 16),
    (94, 32, 16),
    (95, 32, 16),
    (96, 32, 16),
    (97, 33, 17),
    (98, 33, 17),
    (99, 33, 17),
    (100, 34, 17),
    (101, 34, 17),
    (102, 34, 17),
    (103, 35, 18),
    (104, 35, 18),
    (105, 35, 18),
    (106, 36, 18),
    (107, 36, 18),
    (108, 36, 18),
    (109, 37, 19),
    (110, 37, 19),
    (111, 37, 19),
    (112, 38, 19),
    (113, 38, 19),
    (114, 38, 19);

INSERT INTO DimReseller (ResellerName, GeographyKey)
VALUES
    ('Toy World', 12),
    ('Playland Supplies', 29),
    ('EduToys Co.', 47),
    ('Outdoor Fun Ltd.', 68),
    ('Gadget Galaxy', 85),
    ('GameHub Inc.', 56),
    ('Puzzle Masters', 32),
    ('SoftToys Co.', 93),
    ('Toy Vehicles Ltd.', 7),
    ('Kids Kingdom', 14),
    ('Toys 4 All', 52),
    ('Learning Corner', 24),
    ('Fun in the Sun', 37),
    ('TechToys', 73),
    ('Board Games Central', 5),
    ('Puzzler''s Paradise', 83),
    ('Cuddle Buddies', 19),
    ('Mini Motors Inc.', 42),
    ('The Toy Store', 78),
    ('Family Fun Supplies', 15),
    ('SmartKids', 49),
    ('Playtime Ltd.', 63),
    ('Junior Engineers', 36),
    ('Adventure Toys', 58),
    ('Tiny Techies', 28),
    ('Board Games World', 40),
    ('Puzzle Universe', 54),
    ('Fuzzy Friends', 9),
    ('Motor Toy Co.', 70),
    ('All Around Toys', 18);

INSERT INTO FactSales (ProductKey, ResellerKey, OrderDate, SalesAmount) 
VALUES
	(20, 18, '2022-01-04', 539.67),
	(22, 3, '2022-01-06', 418.16),
	(1, 19, '2022-01-10', 546.12),
	(5, 19, '2022-01-12', 922.87),
	(10, 10, '2022-01-14', 461.66),
	(3, 22, '2022-01-20', 677.33),
	(14, 17, '2022-01-20', 247.35),
	(24, 30, '2022-01-30', 46.01),
	(23, 10, '2022-02-11', 310.65),
	(8, 5, '2022-02-16', 999.67),
	(2, 3, '2022-02-25', 647.97),
	(22, 12, '2022-02-25', 922.0),
	(20, 23, '2022-03-05', 597.75),
	(8, 22, '2022-03-13', 331.79),
	(2, 23, '2022-03-16', 689.55),
	(8, 30, '2022-03-17', 456.49),
	(16, 29, '2022-04-05', 596.43),
	(8, 2, '2022-04-11', 829.46),
	(2, 7, '2022-04-11', 581.88),
	(18, 18, '2022-04-16', 583.03),
	(24, 28, '2022-04-19', 992.16),
	(4, 8, '2022-04-21', 535.09),
	(2, 3, '2022-05-06', 11.68),
	(4, 13, '2022-05-14', 828.24),
	(18, 27, '2022-05-17', 56.66),
	(10, 9, '2022-05-20', 502.63),
	(16, 30, '2022-06-02', 640.62),
	(9, 19, '2022-06-07', 94.33),
	(13, 3, '2022-06-13', 671.01),
	(11, 9, '2022-06-17', 100.37),
	(22, 15, '2022-06-29', 879.41),
	(6, 1, '2022-07-14', 678.95),
	(11, 12, '2022-07-14', 269.92),
	(6, 29, '2022-07-15', 415.3),
	(19, 28, '2022-07-16', 542.94),
	(23, 24, '2022-07-16', 104.83),
	(20, 19, '2022-07-22', 877.08),
	(19, 11, '2022-07-29', 622.67),
	(4, 6, '2022-07-30', 347.04),
	(12, 30, '2022-08-13', 270.88),
	(20, 24, '2022-08-15', 994.36),
	(10, 17, '2022-08-21', 355.0),
	(6, 29, '2022-08-22', 327.49),
	(6, 10, '2022-09-02', 298.73),
	(13, 7, '2022-09-10', 408.28),
	(5, 17, '2022-09-13', 266.5),
	(11, 21, '2022-09-15', 418.82),
	(3, 1, '2022-09-26', 272.07),
	(24, 24, '2022-09-30', 705.72),
	(20, 19, '2022-10-05', 658.57),
	(10, 18, '2022-10-09', 725.81),
	(12, 18, '2022-10-12', 72.04),
	(9, 13, '2022-10-13', 764.72),
	(12, 17, '2022-10-14', 543.3),
	(1, 25, '2022-10-16', 824.75),
	(6, 12, '2022-10-27', 57.32),
	(21, 8, '2022-10-30', 739.53),
	(19, 2, '2022-11-04', 283.03),
	(1, 22, '2022-11-05', 78.77),
	(3, 16, '2022-11-08', 399.72),
	(23, 17, '2022-11-08', 221.55),
	(8, 23, '2022-11-09', 497.12),
	(12, 4, '2022-11-19', 330.48),
	(4, 21, '2022-11-23', 983.86),
	(6, 30, '2022-12-14', 744.33),
	(1, 7, '2022-12-23', 906.24),
	(18, 3, '2022-12-25', 984.01),
	(21, 18, '2022-12-27', 383.27),
	(11, 30, '2023-01-01', 466.18),
	(15, 6, '2023-01-14', 112.52),
	(22, 23, '2023-01-15', 395.91),
	(4, 15, '2023-01-19', 818.14),
	(7, 10, '2023-01-21', 534.76),
	(6, 8, '2023-01-22', 578.13),
	(5, 20, '2023-01-27', 997.89),
	(17, 15, '2023-01-31', 187.28),
	(8, 11, '2023-02-07', 178.57),
	(15, 9, '2023-02-18', 128.64),
	(19, 4, '2023-02-27', 214.26),
	(10, 27, '2023-03-06', 267.22),
	(4, 12, '2023-03-08', 63.16),
	(12, 17, '2023-03-15', 456.51),
	(21, 12, '2023-03-21', 399.51),
	(6, 21, '2023-03-29', 897.05),
	(3, 4, '2023-04-06', 288.44),
	(8, 27, '2023-04-17', 664.01),
	(21, 28, '2023-04-18', 899.1),
	(15, 23, '2023-04-21', 946.61),
	(18, 9, '2023-04-26', 940.46),
	(6, 17, '2023-04-29', 492.54),
	(19, 25, '2023-04-29', 662.49),
	(7, 1, '2023-04-30', 269.3),
	(20, 27, '2023-04-30', 752.21),
	(20, 4, '2023-05-01', 864.78),
	(24, 25, '2023-05-11', 558.25),
	(17, 28, '2023-05-13', 60.08),
	(16, 13, '2023-05-16', 939.92),
	(13, 11, '2023-05-27', 721.18),
	(14, 8, '2023-05-28', 393.61),
	(3, 2, '2023-06-20', 731.16),
	(6, 29, '2023-06-30', 133.86),
	(5, 23, '2023-07-02', 968.72),
	(8, 16, '2023-07-07', 568.13),
	(18, 10, '2023-07-08', 632.17),
	(8, 16, '2023-07-11', 28.24),
	(3, 8, '2023-07-16', 452.32),
	(7, 10, '2023-07-17', 125.92),
	(21, 4, '2023-07-21', 272.82),
	(10, 15, '2023-07-26', 548.4),
	(15, 19, '2023-08-07', 680.24),
	(24, 27, '2023-08-08', 193.12),
	(8, 30, '2023-08-09', 33.71),
	(18, 25, '2023-08-09', 214.08),
	(2, 22, '2023-09-01', 929.57),
	(20, 14, '2023-09-01', 549.59),
	(7, 24, '2023-09-21', 559.37),
	(19, 22, '2023-09-23', 980.84),
	(22, 9, '2023-09-29', 247.04),
	(17, 16, '2023-10-18', 606.21),
	(16, 13, '2023-10-22', 565.55),
	(12, 12, '2023-10-22', 921.06),
	(24, 6, '2023-10-24', 953.97),
	(4, 17, '2023-10-28', 707.57),
	(4, 11, '2023-11-07', 794.69),
	(16, 29, '2023-11-13', 849.05),
	(16, 19, '2023-11-16', 380.95),
	(4, 11, '2023-11-21', 542.14),
	(10, 11, '2023-11-26', 467.45),
	(15, 9, '2023-12-15', 67.31),
	(2, 11, '2023-12-27', 328.06),
	(4, 30, '2024-01-01', 840.4),
	(17, 22, '2024-01-02', 232.24),
	(7, 7, '2024-01-06', 616.53),
	(21, 7, '2024-01-09', 342.68),
	(23, 15, '2024-01-13', 925.87),
	(11, 15, '2024-01-18', 256.95),
	(23, 2, '2024-01-26', 333.55),
	(7, 14, '2024-01-28', 786.23),
	(17, 7, '2024-02-03', 633.49),
	(21, 27, '2024-02-12', 657.24),
	(5, 4, '2024-02-20', 921.77),
	(16, 14, '2024-02-26', 633.68),
	(7, 26, '2024-03-02', 795.73),
	(11, 16, '2024-03-06', 152.7),
	(3, 6, '2024-03-11', 117.85),
	(2, 24, '2024-03-12', 585.68),
	(8, 14, '2024-03-14', 969.15),
	(13, 10, '2024-03-15', 163.29),
	(18, 27, '2024-03-19', 216.11),
	(1, 30, '2024-03-20', 877.02),
	(2, 27, '2024-03-22', 285.3),
	(13, 8, '2024-03-25', 819.29),
	(18, 13, '2024-03-29', 374.39),
	(15, 29, '2024-03-30', 458.38),
	(17, 6, '2024-04-06', 496.16),
	(5, 3, '2024-04-09', 46.9),
	(16, 22, '2024-04-10', 104.61),
	(4, 10, '2024-04-17', 367.78),
	(7, 27, '2024-04-20', 447.03),
	(6, 28, '2024-04-22', 43.55),
	(9, 8, '2024-04-23', 125.39),
	(1, 26, '2024-04-27', 610.2),
	(22, 13, '2024-05-02', 848.2),
	(15, 24, '2024-05-05', 539.53),
	(2, 6, '2024-05-07', 409.95),
	(12, 7, '2024-06-06', 187.64),
	(6, 27, '2024-06-07', 459.08),
	(7, 17, '2024-06-07', 633.89),
	(17, 3, '2024-06-10', 835.12),
	(6, 1, '2024-06-22', 534.47),
	(15, 4, '2024-07-07', 609.26),
	(5, 13, '2024-07-08', 137.62),
	(3, 24, '2024-07-11', 254.85),
	(7, 16, '2024-07-21', 23.69),
	(19, 4, '2024-07-27', 597.66),
	(18, 25, '2024-07-30', 837.83),
	(16, 21, '2024-08-03', 821.41),
	(1, 4, '2024-08-08', 192.28),
	(21, 22, '2024-08-11', 271.5),
	(24, 20, '2024-08-22', 727.14),
	(10, 6, '2024-08-27', 481.58),
	(21, 30, '2024-09-03', 706.99),
	(18, 28, '2024-09-06', 373.45),
	(3, 6, '2024-09-12', 624.82),
	(22, 15, '2024-09-20', 807.35),
	(5, 22, '2024-09-28', 649.74),
	(7, 19, '2024-10-04', 562.06),
	(6, 18, '2024-10-12', 732.2),
	(18, 30, '2024-10-18', 693.75),
	(4, 14, '2024-10-21', 500.43);